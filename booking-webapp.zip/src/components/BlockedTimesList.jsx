'use client';

import { useState, useEffect } from 'react';
import { getBlockedTimes } from '@/lib/firestore';
import { formatDate, formatTime } from '@/lib/utils';

export default function BlockedTimesList() {
  const [blockedTimes, setBlockedTimes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBlockedTimes = async () => {
      try {
        setLoading(true);
        const times = await getBlockedTimes();
        
        // Sort by start time
        times.sort((a, b) => a.startTime.toDate() - b.startTime.toDate());
        
        // Filter out past blocked times
        const now = new Date();
        const futureBlockedTimes = times.filter(time => 
          time.endTime.toDate() > now
        );
        
        setBlockedTimes(futureBlockedTimes);
      } catch (err) {
        console.error('Error fetching blocked times:', err);
        setError('Failed to load unavailable times. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchBlockedTimes();
  }, []);

  if (loading) {
    return <div className="text-center py-4">Loading unavailable times...</div>;
  }

  if (error) {
    return <div className="text-red-500 py-2">{error}</div>;
  }

  if (blockedTimes.length === 0) {
    return null; // Don't show anything if no blocked times
  }

  return (
    <div className="mt-6 border rounded-lg p-4 bg-yellow-50">
      <h3 className="font-medium text-lg mb-3">Unavailable Times</h3>
      <ul className="space-y-2">
        {blockedTimes.map((time) => (
          <li key={time.id} className="text-sm">
            <span className="font-medium">{formatDate(time.startTime)}: </span>
            <span>{formatTime(time.startTime)} - {formatTime(time.endTime)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
