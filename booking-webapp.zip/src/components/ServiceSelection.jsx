'use client';

import { useState, useEffect } from 'react';
import { getServices } from '@/lib/firestore';
import { formatCurrency } from '@/lib/utils';

export default function ServiceSelection({ onSelect, selectedService, artistId }) {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        setLoading(true);
        const servicesData = await getServices();
        
        // Filter services by artist if artistId is provided
        let filteredServices = servicesData.filter(service => service.isActive);
        
        if (artistId) {
          // In a real app, you would filter based on the artist's specialties
          // This is a simplified version
          const artist = await getArtist(artistId);
          if (artist && artist.specialties && artist.specialties.length > 0) {
            filteredServices = filteredServices.filter(service => 
              artist.specialties.includes(service.id)
            );
          }
        }
        
        setServices(filteredServices);
      } catch (err) {
        console.error('Error fetching services:', err);
        setError('Failed to load services. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchServices();
  }, [artistId]);

  if (loading) {
    return <div className="flex justify-center p-8">Loading services...</div>;
  }

  if (error) {
    return <div className="text-red-500 p-4">{error}</div>;
  }

  if (services.length === 0) {
    return <div className="p-4">No services available for the selected artist.</div>;
  }

  return (
    <div className="w-full">
      <h2 className="text-2xl font-bold mb-6">Select a Service</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {services.map((service) => (
          <div
            key={service.id}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              selectedService?.id === service.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-blue-300'
            }`}
            onClick={() => onSelect(service)}
          >
            <div className="flex flex-col h-full">
              <div className="flex justify-between items-start">
                <h3 className="font-semibold text-lg">{service.name}</h3>
                <div className="text-lg font-medium text-blue-600">
                  {formatCurrency(service.price)}
                </div>
              </div>
              <div className="text-sm text-gray-500 mt-1">
                Duration: {service.duration} minutes
              </div>
              <p className="mt-2 text-gray-700 flex-grow">{service.description}</p>
              {service.image && (
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-32 object-cover rounded mt-3"
                />
              )}
              {selectedService?.id === service.id && (
                <div className="mt-2 text-blue-500 text-sm">Selected</div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
