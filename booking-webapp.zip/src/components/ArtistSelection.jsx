// src/components/ArtistSelection.jsx
'use client';

import { useState, useEffect } from 'react';
import { getArtists } from '@/lib/firestore';

export default function ArtistSelection({ onSelect, selectedArtist }) {
  const [artists, setArtists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchArtists = async () => {
      try {
        setLoading(true);
        const artistsData = await getArtists();
        // Only show active artists
        const activeArtists = artistsData.filter(artist => artist.isActive);
        setArtists(activeArtists);
      } catch (err) {
        console.error('Error fetching artists:', err);
        setError('Failed to load artists. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchArtists();
  }, []);

  if (loading) {
    return <div className="flex justify-center p-8">Loading artists...</div>;
  }

  if (error) {
    return <div className="text-red-500 p-4">{error}</div>;
  }

  if (artists.length === 0) {
    return <div className="p-4">No artists available at the moment.</div>;
  }

  return (
    <div className="w-full">
      <h2 className="text-2xl font-bold mb-6">Select an Artist</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {artists.map((artist) => (
          <div
            key={artist.id}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              selectedArtist?.id === artist.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-blue-300'
            }`}
            onClick={() => onSelect(artist)}
          >
            <div className="flex items-center space-x-4">
              {artist.profileImage ? (
                <img
                  src={artist.profileImage}
                  alt={artist.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-500 text-xl">
                    {artist.name.charAt(0)}
                  </span>
                </div>
              )}
              <div>
                <h3 className="font-semibold text-lg">{artist.name}</h3>
                {artist.specialties && artist.specialties.length > 0 && (
                  <p className="text-sm text-gray-600">
                    Specialties: {artist.specialties.join(', ')}
                  </p>
                )}
              </div>
            </div>
            {selectedArtist?.id === artist.id && (
              <div className="mt-2 text-blue-500 text-sm">Selected</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
