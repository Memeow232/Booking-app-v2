'use client';

import { useState, useEffect } from 'react';
import { getAvailableTimeSlots } from '@/lib/firestore';
import { formatTime } from '@/lib/utils';

export default function TimeSelection({ 
  onSelect, 
  selectedTime, 
  selectedDate, 
  artistId, 
  serviceId 
}) {
  const [timeSlots, setTimeSlots] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTimeSlots = async () => {
      if (!selectedDate || !artistId || !serviceId) {
        return;
      }

      try {
        setLoading(true);
        const availableSlots = await getAvailableTimeSlots(selectedDate, artistId, serviceId);
        setTimeSlots(availableSlots);
        setError(null);
      } catch (err) {
        console.error('Error fetching time slots:', err);
        setError('Failed to load available time slots. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchTimeSlots();
  }, [selectedDate, artistId, serviceId]);

  if (!selectedDate) {
    return (
      <div className="w-full">
        <h2 className="text-2xl font-bold mb-6">Select a Time</h2>
        <div className="border rounded-lg p-6 bg-gray-50 text-center">
          <p className="text-gray-600">Please select a date first</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="w-full">
        <h2 className="text-2xl font-bold mb-6">Select a Time</h2>
        <div className="flex justify-center p-8">Loading available times...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full">
        <h2 className="text-2xl font-bold mb-6">Select a Time</h2>
        <div className="text-red-500 p-4">{error}</div>
      </div>
    );
  }

  if (timeSlots.length === 0) {
    return (
      <div className="w-full">
        <h2 className="text-2xl font-bold mb-6">Select a Time</h2>
        <div className="border rounded-lg p-6 bg-yellow-50 text-center">
          <p className="text-yellow-700">No available time slots for the selected date.</p>
          <p className="mt-2 text-gray-600">Please select a different date.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      <h2 className="text-2xl font-bold mb-6">Select a Time</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {timeSlots.map((slot, index) => (
          <div
            key={index}
            className={`border rounded-lg p-3 text-center cursor-pointer transition-all ${
              selectedTime && 
              selectedTime.getTime() === slot.startTime.getTime()
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-blue-300'
            }`}
            onClick={() => onSelect(slot.startTime)}
          >
            <div className="font-medium">
              {formatTime(slot.startTime)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              to {formatTime(slot.endTime)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
