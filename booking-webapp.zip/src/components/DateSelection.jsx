'use client';

import { useState } from 'react';
import { DayPicker } from 'react-day-picker';
import { isPastDate, formatDate } from '@/lib/utils';
import 'react-day-picker/dist/style.css';

export default function DateSelection({ onSelect, selectedDate }) {
  const [error, setError] = useState(null);
  
  const handleDateSelect = (date) => {
    if (isPastDate(date)) {
      setError('Cannot select a date in the past');
      return;
    }
    
    setError(null);
    onSelect(date);
  };
  
  // Disable past dates
  const disabledDays = { before: new Date() };
  
  return (
    <div className="w-full">
      <h2 className="text-2xl font-bold mb-6">Select a Date</h2>
      
      <div className="flex flex-col md:flex-row gap-6">
        <div className="border rounded-lg p-4 bg-white shadow-sm">
          <DayPicker
            mode="single"
            selected={selectedDate}
            onSelect={handleDateSelect}
            disabled={disabledDays}
            modifiersClassNames={{
              selected: 'bg-blue-500 text-white rounded',
              today: 'text-orange-500 font-bold',
            }}
          />
        </div>
        
        <div className="flex-1">
          {error && (
            <div className="text-red-500 mb-4">{error}</div>
          )}
          
          {selectedDate && !error && (
            <div className="border rounded-lg p-4 bg-blue-50">
              <h3 className="font-medium text-lg mb-2">Selected Date</h3>
              <p className="text-blue-700">{formatDate(selectedDate)}</p>
              <p className="mt-4 text-gray-600">
                Please select this date to see available time slots.
              </p>
            </div>
          )}
          
          {!selectedDate && !error && (
            <div className="border rounded-lg p-4 bg-gray-50">
              <h3 className="font-medium text-lg mb-2">Date Selection</h3>
              <p className="text-gray-600">
                Please select a date from the calendar to see available time slots.
              </p>
              <ul className="mt-4 text-sm text-gray-500 space-y-2">
                <li>• Dates in the past are not available</li>
                <li>• Weekends may have limited availability</li>
                <li>• Special holidays may have different hours</li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
