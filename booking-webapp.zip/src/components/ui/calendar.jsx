'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

const Calendar = React.forwardRef(({ className, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn(
        "p-3 bg-white rounded-lg shadow border border-gray-200",
        className
      )}
      {...props}
    >
      <div className="grid grid-cols-7 gap-2 mb-2">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
          <div key={i} className="text-center text-sm font-medium text-gray-500">
            {day}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-2">
        {Array.from({ length: 35 }).map((_, i) => {
          const isToday = i === 14; // Example: 15th day is today
          const isSelected = i === 21; // Example: 22nd day is selected
          const isDisabled = i < 5 || i > 30; // Example: First and last few days disabled
          
          return (
            <button
              key={i}
              disabled={isDisabled}
              className={cn(
                "h-9 w-9 rounded-md text-sm p-0 font-normal flex items-center justify-center",
                isDisabled && "text-gray-300 cursor-not-allowed",
                !isDisabled && !isToday && !isSelected && "text-gray-900 hover:bg-gray-100",
                isToday && !isSelected && "bg-blue-50 text-blue-600 font-medium",
                isSelected && "bg-blue-600 text-white font-medium"
              )}
            >
              {i - 4 > 0 && i - 4 <= 31 ? i - 4 : ""}
            </button>
          );
        })}
      </div>
    </div>
  );
});
Calendar.displayName = "Calendar";

export { Calendar };
