'use client';

import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminAuthWrapper({ children }) {
  const router = useRouter();

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('adminLoggedIn');
    if (isLoggedIn !== 'true') {
      router.push('/admin/login');
    }
  }, [router]);

  return <>{children}</>;
}
