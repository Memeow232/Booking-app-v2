'use client';

import React, { useState, useEffect } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectOption } from '@/components/ui/select';
import { getArtists, getServices, createBooking, createClient, getAvailableTimeSlots } from '@/lib/firestore';
import { verifyAge, formatDate, formatTime } from '@/lib/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';

export default function BookingPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  
  // Step 1: Artist Selection
  const [artists, setArtists] = useState([]);
  const [selectedArtist, setSelectedArtist] = useState(null);
  
  // Step 2: Service Selection
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState(null);
  
  // Step 3: Date Selection
  const [selectedDate, setSelectedDate] = useState(null);
  const [availableDates, setAvailableDates] = useState([]);
  
  // Step 4: Time Selection
  const [availableTimeSlots, setAvailableTimeSlots] = useState([]);
  const [selectedTime, setSelectedTime] = useState(null);
  
  // Step 5: Client Information
  const [clientInfo, setClientInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    notes: ''
  });
  
  // Fetch artists on component mount
  useEffect(() => {
    const fetchArtists = async () => {
      try {
        setLoading(true);
        const artistsData = await getArtists();
        setArtists(artistsData.filter(artist => artist.isActive));
        setLoading(false);
      } catch (err) {
        console.error('Error fetching artists:', err);
        setError('Failed to load artists. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchArtists();
  }, []);
  
  // Fetch services when artist is selected
  useEffect(() => {
    if (selectedArtist) {
      const fetchServices = async () => {
        try {
          setLoading(true);
          const servicesData = await getServices();
          setServices(
            servicesData
              .filter(service => 
                service.isActive && 
                (service.artistId === selectedArtist.id || !service.artistId)
              )
          );
          setLoading(false);
        } catch (err) {
          console.error('Error fetching services:', err);
          setError('Failed to load services. Please try again later.');
          setLoading(false);
        }
      };
      
      fetchServices();
    }
  }, [selectedArtist]);
  
  // Generate available dates (next 30 days)
  useEffect(() => {
    if (selectedService) {
      const dates = [];
      const today = new Date();
      
      for (let i = 0; i < 30; i++) {
        const date = new Date();
        date.setDate(today.getDate() + i);
        
        // Skip Sundays (or any other day you want to exclude)
        if (date.getDay() !== 0) {
          dates.push(date);
        }
      }
      
      setAvailableDates(dates);
    }
  }, [selectedService]);
  
  // Fetch available time slots when date is selected
  useEffect(() => {
    if (selectedArtist && selectedService && selectedDate) {
      const fetchTimeSlots = async () => {
        try {
          setLoading(true);
          const slots = await getAvailableTimeSlots(
            selectedDate,
            selectedArtist.id,
            selectedService.id
          );
          setAvailableTimeSlots(slots);
          setLoading(false);
        } catch (err) {
          console.error('Error fetching time slots:', err);
          setError('Failed to load available times. Please try again later.');
          setLoading(false);
        }
      };
      
      fetchTimeSlots();
    }
  }, [selectedArtist, selectedService, selectedDate]);
  
  // Handle artist selection
  const handleArtistSelect = (artist) => {
    setSelectedArtist(artist);
    setSelectedService(null);
    setSelectedDate(null);
    setSelectedTime(null);
    setCurrentStep(2);
  };
  
  // Handle service selection
  const handleServiceSelect = (service) => {
    setSelectedService(service);
    setSelectedDate(null);
    setSelectedTime(null);
    setCurrentStep(3);
  };
  
  // Handle date selection
  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setSelectedTime(null);
    setCurrentStep(4);
  };
  
  // Handle time selection
  const handleTimeSelect = (time) => {
    setSelectedTime(time);
    setCurrentStep(5);
  };
  
  // Handle client info change
  const handleClientInfoChange = (e) => {
    const { name, value } = e.target;
    setClientInfo({
      ...clientInfo,
      [name]: value
    });
  };
  
  // Handle booking submission
  const handleSubmitBooking = async () => {
    // Validate client information
    if (!clientInfo.firstName || !clientInfo.lastName || !clientInfo.email || !clientInfo.phone || !clientInfo.dateOfBirth) {
      setError('Please fill in all required fields.');
      return;
    }
    
    // Validate age (18+)
    if (!verifyAge(clientInfo.dateOfBirth)) {
      setError('You must be at least 18 years old to book an appointment.');
      return;
    }
    
    try {
      setLoading(true);
      
      // Create client
      const clientId = await createClient({
        firstName: clientInfo.firstName,
        lastName: clientInfo.lastName,
        email: clientInfo.email,
        phone: clientInfo.phone,
        dateOfBirth: new Date(clientInfo.dateOfBirth)
      });
      
      // Create booking
      await createBooking({
        artistId: selectedArtist.id,
        serviceId: selectedService.id,
        clientId: clientId,
        date: selectedDate,
        time: selectedTime,
        notes: clientInfo.notes,
        status: 'confirmed'
      });
      
      setSuccess(true);
      setLoading(false);
      
      // Reset form
      setSelectedArtist(null);
      setSelectedService(null);
      setSelectedDate(null);
      setSelectedTime(null);
      setClientInfo({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        dateOfBirth: '',
        notes: ''
      });
      setCurrentStep(1);
    } catch (err) {
      console.error('Error creating booking:', err);
      setError('Failed to create booking. Please try again later.');
      setLoading(false);
    }
  };
  
  // Go to previous step
  const handlePrevStep = () => {
    setCurrentStep(currentStep - 1);
  };
  
  // Render step content based on current step
  const renderStepContent = () => {
    switch (currentStep) {
      case 1: // Artist Selection
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {artists.map((artist) => (
              <Card 
                key={artist.id} 
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedArtist?.id === artist.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => handleArtistSelect(artist)}
              >
                <CardHeader>
                  <CardTitle>{artist.name}</CardTitle>
                  <CardDescription>{artist.specialties}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500">{artist.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        );
        
      case 2: // Service Selection
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((service) => (
              <Card 
                key={service.id} 
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedService?.id === service.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => handleServiceSelect(service)}
              >
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle>{service.name}</CardTitle>
                    <Badge>${service.price.toFixed(2)}</Badge>
                  </div>
                  <CardDescription>{service.duration} minutes</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        );
        
      case 3: // Date Selection
        return (
          <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-1">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                disabled={(date) => {
                  // Disable dates in the past
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  
                  // Disable Sundays
                  return date < today || date.getDay() === 0;
                }}
                className="rounded-md border shadow"
              />
            </div>
            <div className="flex-1">
              <Card>
                <CardHeader>
                  <CardTitle>Selected Service</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Service:</span>
                      <span>{selectedService.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Duration:</span>
                      <span>{selectedService.duration} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Price:</span>
                      <span>${selectedService.price.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Artist:</span>
                      <span>{selectedArtist.name}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );
        
      case 4: // Time Selection
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-medium">Select a Time</h3>
            <p className="text-gray-500">
              Available time slots for {formatDate(selectedDate)}
            </p>
            
            {availableTimeSlots.length === 0 ? (
              <Alert>
                <AlertTitle>No available times</AlertTitle>
                <AlertDescription>
                  There are no available time slots for the selected date. Please select another date.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {availableTimeSlots.map((slot) => (
                  <Button
                    key={slot.value}
                    variant={selectedTime?.value === slot.value ? "default" : "outline"}
                    onClick={() => handleTimeSelect(slot)}
                  >
                    {slot.label}
                  </Button>
                ))}
              </div>
            )}
          </div>
        );
        
      case 5: // Client Information
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Service:</span>
                      <span>{selectedService.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Artist:</span>
                      <span>{selectedArtist.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Date:</span>
                      <span>{formatDate(selectedDate)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Time:</span>
                      <span>{selectedTime.label}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Duration:</span>
                      <span>{selectedService.duration} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Price:</span>
                      <span>${selectedService.price.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={clientInfo.firstName}
                      onChange={handleClientInfoChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={clientInfo.lastName}
                      onChange={handleClientInfoChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={clientInfo.email}
                    onChange={handleClientInfoChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={clientInfo.phone}
                    onChange={handleClientInfoChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth * (Must be 18+)</Label>
                  <Input
                    id="dateOfBirth"
                    name="dateOfBirth"
                    type="date"
                    value={clientInfo.dateOfBirth}
                    onChange={handleClientInfoChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Input
                    id="notes"
                    name="notes"
                    value={clientInfo.notes}
                    onChange={handleClientInfoChange}
                  />
                </div>
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  if (success) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <Card className="w-full">
          <CardHeader>
            <CardTitle className="text-center text-2xl text-green-600">Booking Confirmed!</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert variant="success">
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>
                Your booking has been confirmed. We've sent a confirmation email with all the details.
              </AlertDescription>
            </Alert>
            
            <div className="text-center">
              <Button onClick={() => setSuccess(false)}>Book Another Appointment</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-center text-2xl">Book Your Appointment</CardTitle>
          <CardDescription className="text-center">
            Complete the steps below to book your appointment
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {/* Progress Steps */}
          <div className="relative">
            <div className="flex justify-between mb-2">
              {['Artist', 'Service', 'Date', 'Time', 'Details'].map((step, index) => (
                <div 
                  key={index} 
                  className={`flex flex-col items-center ${
                    index + 1 === currentStep 
                      ? 'text-primary font-medium' 
                      : index + 1 < currentStep 
                        ? 'text-green-600' 
                        : 'text-gray-400'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                    index + 1 === currentStep 
                      ? 'bg-primary text-white' 
                      : index + 1 < currentStep 
                        ? 'bg-green-600 text-white' 
                        : 'bg-gray-200 text-gray-500'
                  }`}>
                    {index + 1 < currentStep ? '✓' : index + 1}
                  </div>
                  <span className="text-xs sm:text-sm">{step}</span>
                </div>
              ))}
            </div>
            <div className="absolute top-4 left-0 right-0 h-0.5 bg-gray-200 -z-10">
              <div 
                className="h-full bg-green-600 transition-all" 
                style={{ width: `${(currentStep - 1) * 25}%` }}
              ></div>
            </div>
          </div>
          
          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative">
              {error}
            </div>
          )}
          
          {/* Step Content */}
          <div className="mt-8">
            {renderStepContent()}
            
            {/* Show blocked times on date selection step */}
            {currentStep === 3 && <BlockedTimesList />}
          </div>
          
          {/* Navigation Buttons */}
          <div className="mt-8 flex justify-between">
            {currentStep > 1 && (
              <Button variant="outline" onClick={handlePrevStep}>
                Back
              </Button>
            )}
            
            {currentStep === 5 && (
              <Button 
                onClick={handleSubmitBooking}
                disabled={loading}
              >
                {loading ? 'Processing...' : 'Confirm Booking'}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
