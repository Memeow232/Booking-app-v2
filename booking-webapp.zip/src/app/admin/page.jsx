'use client';

import React, { useState, useEffect } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Calendar } from '@/components/ui/calendar';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { getArtists, getServices, getBlockedTimes, createArtist, updateArtist, deleteArtist, createService, updateService, deleteService, createBlockedTime, deleteBlockedTime } from '@/lib/firestore';
import { formatDate, formatTime } from '@/lib/utils';
import AdminAuthWrapper from '@/components/AdminAuthWrapper';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('artists');
  const [artists, setArtists] = useState([]);
  const [services, setServices] = useState([]);
  const [blockedTimes, setBlockedTimes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Artist form state
  const [artistDialogOpen, setArtistDialogOpen] = useState(false);
  const [editingArtist, setEditingArtist] = useState(null);
  const [artistForm, setArtistForm] = useState({
    name: '',
    bio: '',
    specialties: '',
    imageUrl: '',
    isActive: true
  });
  
  // Service form state
  const [serviceDialogOpen, setServiceDialogOpen] = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [serviceForm, setServiceForm] = useState({
    name: '',
    description: '',
    duration: 60,
    price: 0,
    artistId: '',
    isActive: true
  });
  
  // Time blocking form state
  const [timeBlockDialogOpen, setTimeBlockDialogOpen] = useState(false);
  const [timeBlockForm, setTimeBlockForm] = useState({
    artistId: '',
    startDate: '',
    startTime: '',
    endDate: '',
    endTime: '',
    reason: ''
  });

  // Success/error messages
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Fetch data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch artists
        const artistsData = await getArtists();
        setArtists(artistsData);
        
        // Fetch services
        const servicesData = await getServices();
        setServices(servicesData);
        
        // Fetch blocked times
        const blockedTimesData = await getBlockedTimes();
        setBlockedTimes(blockedTimesData);
        
        setLoading(false);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load data. Please try again.');
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);

  // Handle artist form changes
  const handleArtistFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setArtistForm({
      ...artistForm,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  // Handle service form changes
  const handleServiceFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setServiceForm({
      ...serviceForm,
      [name]: type === 'checkbox' 
        ? checked 
        : (name === 'duration' || name === 'price') 
          ? Number(value) 
          : value
    });
  };

  // Handle time block form changes
  const handleTimeBlockFormChange = (e) => {
    const { name, value } = e.target;
    setTimeBlockForm({
      ...timeBlockForm,
      [name]: value
    });
  };

  // Open artist dialog for creating or editing
  const openArtistDialog = (artist = null) => {
    if (artist) {
      setEditingArtist(artist);
      setArtistForm({
        name: artist.name,
        bio: artist.bio || '',
        specialties: artist.specialties || '',
        imageUrl: artist.imageUrl || '',
        isActive: artist.isActive
      });
    } else {
      setEditingArtist(null);
      setArtistForm({
        name: '',
        bio: '',
        specialties: '',
        imageUrl: '',
        isActive: true
      });
    }
    setArtistDialogOpen(true);
  };

  // Open service dialog for creating or editing
  const openServiceDialog = (service = null) => {
    if (service) {
      setEditingService(service);
      setServiceForm({
        name: service.name,
        description: service.description || '',
        duration: service.duration,
        price: service.price,
        artistId: service.artistId,
        isActive: service.isActive
      });
    } else {
      setEditingService(null);
      setServiceForm({
        name: '',
        description: '',
        duration: 60,
        price: 0,
        artistId: artists.length > 0 ? artists[0].id : '',
        isActive: true
      });
    }
    setServiceDialogOpen(true);
  };

  // Open time block dialog
  const openTimeBlockDialog = () => {
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    
    setTimeBlockForm({
      artistId: artists.length > 0 ? artists[0].id : '',
      startDate: formattedDate,
      startTime: '09:00',
      endDate: formattedDate,
      endTime: '10:00',
      reason: ''
    });
    
    setTimeBlockDialogOpen(true);
  };

  // Save artist
  const saveArtist = async () => {
    try {
      if (!artistForm.name) {
        setErrorMessage('Artist name is required');
        return;
      }
      
      if (editingArtist) {
        // Update existing artist
        await updateArtist(editingArtist.id, artistForm);
        
        // Update local state
        setArtists(artists.map(a => 
          a.id === editingArtist.id ? { ...a, ...artistForm, id: a.id } : a
        ));
        
        setSuccessMessage('Artist updated successfully');
      } else {
        // Create new artist
        const newArtistId = await createArtist(artistForm);
        
        // Update local state
        setArtists([...artists, { ...artistForm, id: newArtistId }]);
        
        setSuccessMessage('Artist created successfully');
      }
      
      setArtistDialogOpen(false);
    } catch (err) {
      console.error('Error saving artist:', err);
      setErrorMessage('Failed to save artist. Please try again.');
    }
  };

  // Save service
  const saveService = async () => {
    try {
      if (!serviceForm.name) {
        setErrorMessage('Service name is required');
        return;
      }
      
      if (editingService) {
        // Update existing service
        await updateService(editingService.id, serviceForm);
        
        // Update local state
        setServices(services.map(s => 
          s.id === editingService.id ? { ...s, ...serviceForm, id: s.id } : s
        ));
        
        setSuccessMessage('Service updated successfully');
      } else {
        // Create new service
        const newServiceId = await createService(serviceForm);
        
        // Update local state
        setServices([...services, { ...serviceForm, id: newServiceId }]);
        
        setSuccessMessage('Service created successfully');
      }
      
      setServiceDialogOpen(false);
    } catch (err) {
      console.error('Error saving service:', err);
      setErrorMessage('Failed to save service. Please try again.');
    }
  };

  // Save time block
  const saveTimeBlock = async () => {
    try {
      const { artistId, startDate, startTime, endDate, endTime, reason } = timeBlockForm;
      
      if (!startDate || !startTime || !endDate || !endTime) {
        setErrorMessage('Start and end date/time are required');
        return;
      }
      
      // Create Date objects
      const startDateTime = new Date(`${startDate}T${startTime}`);
      const endDateTime = new Date(`${endDate}T${endTime}`);
      
      if (endDateTime <= startDateTime) {
        setErrorMessage('End time must be after start time');
        return;
      }
      
      // Create blocked time
      const blockData = {
        artistId: artistId === 'all' ? null : artistId,
        startTime: startDateTime,
        endTime: endDateTime,
        reason: reason
      };
      
      const newBlockId = await createBlockedTime(blockData);
      
      // Update local state
      setBlockedTimes([...blockedTimes, { ...blockData, id: newBlockId }]);
      
      setSuccessMessage('Time block created successfully');
      setTimeBlockDialogOpen(false);
    } catch (err) {
      console.error('Error creating time block:', err);
      setErrorMessage('Failed to create time block. Please try again.');
    }
  };

  // Delete artist
  const deleteArtistHandler = async (artistId) => {
    if (window.confirm('Are you sure you want to delete this artist?')) {
      try {
        await deleteArtist(artistId);
        
        // Update local state
        setArtists(artists.filter(a => a.id !== artistId));
        
        setSuccessMessage('Artist deleted successfully');
      } catch (err) {
        console.error('Error deleting artist:', err);
        setErrorMessage('Failed to delete artist. Please try again.');
      }
    }
  };

  // Delete service
  const deleteServiceHandler = async (serviceId) => {
    if (window.confirm('Are you sure you want to delete this service?')) {
      try {
        await deleteService(serviceId);
        
        // Update local state
        setServices(services.filter(s => s.id !== serviceId));
        
        setSuccessMessage('Service deleted successfully');
      } catch (err) {
        console.error('Error deleting service:', err);
        setErrorMessage('Failed to delete service. Please try again.');
      }
    }
  };

  // Delete time block
  const deleteTimeBlockHandler = async (blockId) => {
    if (window.confirm('Are you sure you want to delete this time block?')) {
      try {
        await deleteBlockedTime(blockId);
        
        // Update local state
        setBlockedTimes(blockedTimes.filter(b => b.id !== blockId));
        
        setSuccessMessage('Time block deleted successfully');
      } catch (err) {
        console.error('Error deleting time block:', err);
        setErrorMessage('Failed to delete time block. Please try again.');
      }
    }
  };

  // Clear messages after 5 seconds
  useEffect(() => {
    if (successMessage || errorMessage) {
      const timer = setTimeout(() => {
        setSuccessMessage('');
        setErrorMessage('');
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [successMessage, errorMessage]);

  // Get artist name by ID
  const getArtistName = (artistId) => {
    if (!artistId) return 'All Artists';
    const artist = artists.find(a => a.id === artistId);
    return artist ? artist.name : 'Unknown Artist';
  };

  return (
    <AdminAuthWrapper>
      <div className="container mx-auto p-6 max-w-6xl">
        <header className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Booking Admin Dashboard</h1>
          <p className="text-gray-500">Manage artists, services, and blocked times</p>
        </header>
        
        {/* Success/Error Messages */}
        {successMessage && (
          <Alert variant="success" className="mb-6">
            <AlertTitle>Success</AlertTitle>
            <AlertDescription>{successMessage}</AlertDescription>
          </Alert>
        )}
        
        {errorMessage && (
          <Alert variant="destructive" className="mb-6">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{errorMessage}</AlertDescription>
          </Alert>
        )}
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="artists">Artists</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="blockedTimes">Blocked Times</TabsTrigger>
          </TabsList>
          
          {/* Artists Tab */}
          <TabsContent value="artists">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Artists</CardTitle>
                  <CardDescription>Manage your artists and their information</CardDescription>
                </div>
                <Button onClick={() => openArtistDialog()}>Add Artist</Button>
              </CardHeader>
              <CardContent>
                {artists.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">No artists found</p>
                    <Button onClick={() => openArtistDialog()}>Add Your First Artist</Button>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Specialties</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {artists.map((artist) => (
                        <TableRow key={artist.id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback>{artist.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                              </Avatar>
                              {artist.name}
                            </div>
                          </TableCell>
                          <TableCell>{artist.specialties || '-'}</TableCell>
                          <TableCell>
                            <Badge variant={artist.isActive ? "success" : "outline"}>
                              {artist.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="sm" onClick={() => openArtistDialog(artist)}>
                                Edit
                              </Button>
                              <Button variant="destructive" size="sm" onClick={() => deleteArtistHandler(artist.id)}>
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Services Tab */}
          <TabsContent value="services">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Services</CardTitle>
                  <CardDescription>Manage your service offerings</CardDescription>
                </div>
                <Button onClick={() => openServiceDialog()}>Add Service</Button>
              </CardHeader>
              <CardContent>
                {services.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">No services found</p>
                    <Button onClick={() => openServiceDialog()}>Add Your First Service</Button>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Artist</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {services.map((service) => (
                        <TableRow key={service.id}>
                          <TableCell className="font-medium">{service.name}</TableCell>
                          <TableCell>{getArtistName(service.artistId)}</TableCell>
                          <TableCell>{service.duration} min</TableCell>
                          <TableCell>${service.price.toFixed(2)}</TableCell>
                          <TableCell>
                            <Badge variant={service.isActive ? "success" : "outline"}>
                              {service.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="sm" onClick={() => openServiceDialog(service)}>
                                Edit
                              </Button>
                              <Button variant="destructive" size="sm" onClick={() => deleteServiceHandler(service.id)}>
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Blocked Times Tab */}
          <TabsContent value="blockedTimes">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Blocked Times</CardTitle>
                  <CardDescription>Manage unavailable time slots</CardDescription>
                </div>
                <Button onClick={openTimeBlockDialog}>Block Time</Button>
              </CardHeader>
              <CardContent>
                {blockedTimes.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">No blocked times found</p>
                    <Button onClick={openTimeBlockDialog}>Block Your First Time Slot</Button>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Artist</TableHead>
                        <TableHead>Start Time</TableHead>
                        <TableHead>End Time</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {blockedTimes.map((block) => (
                        <TableRow key={block.id}>
                          <TableCell>{getArtistName(block.artistId)}</TableCell>
                          <TableCell>
                            {formatDate(block.startTime)}<br />
                            {formatTime(block.startTime)}
                          </TableCell>
                          <TableCell>
                            {formatDate(block.endTime)}<br />
                            {formatTime(block.endTime)}
                          </TableCell>
                          <TableCell>{block.reason || '-'}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="destructive" size="sm" onClick={() => deleteTimeBlockHandler(block.id)}>
                              Delete
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        {/* Artist Dialog */}
        <Dialog open={artistDialogOpen} onOpenChange={setArtistDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingArtist ? 'Edit Artist' : 'Add New Artist'}</DialogTitle>
              <DialogDescription>
                {editingArtist 
                  ? 'Update the artist information below.' 
                  : 'Fill in the details to add a new artist.'}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={artistForm.name}
                  onChange={handleArtistFormChange}
                  placeholder="Artist name"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="specialties">Specialties</Label>
                <Input
                  id="specialties"
                  name="specialties"
                  value={artistForm.specialties}
                  onChange={handleArtistFormChange}
                  placeholder="e.g. Haircuts, Coloring"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  name="bio"
                  value={artistForm.bio}
                  onChange={handleArtistFormChange}
                  placeholder="Artist biography"
                  rows={3}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="imageUrl">Profile Image URL</Label>
                <Input
                  id="imageUrl"
                  name="imageUrl"
                  value={artistForm.imageUrl}
                  onChange={handleArtistFormChange}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
              
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isActive"
                  name="isActive"
                  checked={artistForm.isActive}
                  onChange={handleArtistFormChange}
                  className="h-4 w-4 rounded border-gray-300"
                />
                <Label htmlFor="isActive">Active</Label>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setArtistDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={saveArtist}>
                {editingArtist ? 'Update Artist' : 'Add Artist'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        {/* Service Dialog */}
        <Dialog open={serviceDialogOpen} onOpenChange={setServiceDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingService ? 'Edit Service' : 'Add New Service'}</DialogTitle>
              <DialogDescription>
                {editingService 
                  ? 'Update the service information below.' 
                  : 'Fill in the details to add a new service.'}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={serviceForm.name}
                  onChange={handleServiceFormChange}
                  placeholder="Service name"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={serviceForm.description}
                  onChange={handleServiceFormChange}
                  placeholder="Service description"
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    name="duration"
                    type="number"
                    min="15"
                    step="15"
                    value={serviceForm.duration}
                    onChange={handleServiceFormChange}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="price">Price ($)</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={serviceForm.price}
                    onChange={handleServiceFormChange}
                  />
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="artistId">Artist</Label>
                <select
                  id="artistId"
                  name="artistId"
                  value={serviceForm.artistId}
                  onChange={handleServiceFormChange}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {artists.map((artist) => (
                    <option key={artist.id} value={artist.id}>
                      {artist.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isActive"
                  name="isActive"
                  checked={serviceForm.isActive}
                  onChange={handleServiceFormChange}
                  className="h-4 w-4 rounded border-gray-300"
                />
                <Label htmlFor="isActive">Active</Label>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setServiceDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={saveService}>
                {editingService ? 'Update Service' : 'Add Service'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        {/* Time Block Dialog */}
        <Dialog open={timeBlockDialogOpen} onOpenChange={setTimeBlockDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Block Time Slot</DialogTitle>
              <DialogDescription>
                Block a time slot to make it unavailable for booking.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="artistId">Artist</Label>
                <select
                  id="artistId"
                  name="artistId"
                  value={timeBlockForm.artistId}
                  onChange={handleTimeBlockFormChange}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="all">All Artists</option>
                  {artists.map((artist) => (
                    <option key={artist.id} value={artist.id}>
                      {artist.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input
                    id="startDate"
                    name="startDate"
                    type="date"
                    value={timeBlockForm.startDate}
                    onChange={handleTimeBlockFormChange}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="startTime">Start Time</Label>
                  <Input
                    id="startTime"
                    name="startTime"
                    type="time"
                    value={timeBlockForm.startTime}
                    onChange={handleTimeBlockFormChange}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input
                    id="endDate"
                    name="endDate"
                    type="date"
                    value={timeBlockForm.endDate}
                    onChange={handleTimeBlockFormChange}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="endTime">End Time</Label>
                  <Input
                    id="endTime"
                    name="endTime"
                    type="time"
                    value={timeBlockForm.endTime}
                    onChange={handleTimeBlockFormChange}
                  />
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="reason">Reason (optional)</Label>
                <Textarea
                  id="reason"
                  name="reason"
                  value={timeBlockForm.reason}
                  onChange={handleTimeBlockFormChange}
                  placeholder="Reason for blocking this time"
                  rows={2}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setTimeBlockDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={saveTimeBlock}>
                Block Time
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminAuthWrapper>
  );
}
